<?php
include("header.php");
?>

<h1>Dashboard</h1>
<h2>Informacion estadística de la data de la app</h2>

<?php
include("footer.php");
?>
			
