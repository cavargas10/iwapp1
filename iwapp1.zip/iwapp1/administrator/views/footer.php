		</section>
	</section>
	<footer class="piePagina">
		<h6>Derechos Reservados 2022 by: @cavargas10</h6>
	</footer>

</body>
</html>