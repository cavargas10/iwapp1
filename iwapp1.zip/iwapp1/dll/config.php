<?php
	$site_url="http://127.0.0.1/iwapp1";
	$local_path="C:\xampp\htdocs\iwapp1";

	define('DBHOST', '127.0.0.1');
	define('DBUSER', 'root');
	define('DBPASS', '');
	define('DBNAME', 'app1db');
?>